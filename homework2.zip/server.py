import socketserver
import sys
from util.request import Request
import pymongo
import bcrypt
from pymongo import MongoClient
from random import randint
mongo_client = MongoClient("mongo")
db = mongo_client["cse312"]
chat = db["chat-history"]
logins = db["user-info"]
import json
import html
import secrets
import hashlib

def verifyToken(auth):
    return logins.find_one({"auth": auth})

class MyTCPHandler(socketserver.BaseRequestHandler):

    def handle(self):
        received_data = self.request.recv(2048)
        print(self.client_address)
        print("--- received data ---")
        print(received_data)
        print("--- end of data ---\n\n")
        request = Request(received_data)
        headers = [{}]
        values = []
        path = "/visit-counter"
        visits = 0
        i = 0
            
        
        # TODO: Parse the HTTP request and use self.request.sendall(response) to send your response
        
        # check the path to determine what is sent in the response
        # if .contains .html, send index
        # if .contains .css, send css
        # if .png or .jpg, send img
        # anything else, error 404
        # ex: HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 5\r\n\r\nhello
        
        print("request.path: " + request.path)
        
        response = request.http_version + "404 Not Found" + "\r\n"
        response += "Content-Type: text/html; charset=utf-8" + "\r\n"
        response += "Content-Length: "
        error = open("public/404.html", 'r')
        error = error.read().encode()
        response += str(len(error))
        response += "\r\nX-Content-Type-Options: nosniff\r\n\r\n"
        response = response.encode('utf-8')
        response += error
        
        if request.path == "/":
            response = request.http_version + " 200 OK" + "\r\n"
            response += "Content-Type: text/html; charset=utf-8" + "\r\n"
            response += "Content-Length: "
            index = open("public/index.html", 'r')
            index = index.read().encode()
            response += str(len(index))
            response += "\r\nX-Content-Type-Options: nosniff\r\n\r\n"
            response = response.encode('utf-8')
            response += index
        elif ".css" in request.path:
            response = request.http_version + " 200 OK" + "\r\n"
            response += "Content-Type: text/css; charset=utf-8" + "\r\n"
            response += "Content-Length: "
            css = open("public/style.css", 'r')
            css = css.read().encode('utf-8')
            response += str(len(css))
            response += "\r\nX-Content-Type-Options: nosniff\r\n\r\n"
            response = response.encode('utf-8')
            response += css
        elif ".js" in request.path:
            response = request.http_version + " 200 OK" + "\r\n"
            response += "Content-Type: text/javascript; charset=utf-8" + "\r\n"
            response += "Content-Length: "
            js = open(request.path[1:len(request.path)], 'r')
            js = js.read().encode('utf-8')
            response += str(len(js))
            response += "\r\nX-Content-Type-Options: nosniff\r\n\r\n"
            response = response.encode('utf-8')
            response += js
        elif ".png" in request.path:
            response = request.http_version + " 200 OK" + "\r\n"
            response += "Content-Type: image/png" + "\r\n"
            response += "Content-Length: "
            img = open(request.path[1:len(request.path)], 'rb')
            img = img.read()
            response += (str(len(img)))
            response += ("\r\nX-Content-Type-Options: nosniff\r\n\r\n")
            response = response.encode('utf-8')
            response += img
        elif ".jpg" in request.path or ".jpeg" in request.path:
            response = request.http_version + " 200 OK" + "\r\n"
            response += "Content-Type: image/jpeg" + "\r\n"
            response += "Content-Length: "
            img = open(request.path[1:len(request.path)],'rb')
            img = img.read()
            response += (str(len(img)))
            response += ("\r\nX-Content-Type-Options: nosniff\r\n\r\n")
            response = response.encode('utf-8')
            response += img
        elif path in request.path:
            response = request.http_version + " 200 OK" + "\r\n"
            response += "Content-Type: text/html; charset=utf-8" + "\r\n"
            
            if "visits" in request.cookies:
                request.cookies["visits"] = int(request.cookies["visits"]) + 1
                response += "Set-Cookie: " + "visits=" + str(request.cookies["visits"]) + "; Max-Age=3600" + "\r\n"
            else:
                response += "Set-Cookie: " + "visits=" + str(1) + "; Max-Age=3600" + "\r\n"
                
            visit = open("public/visits.html", 'r')
            visit = visit.read().encode()
            response += "Content-Length: "
            response += str(len(visit)) + "\r\n"
            response += "X-Content-Type-Options: nosniff\r\n\r\n"
            
            response = response.encode('utf-8')
            response += visit
            print("headers: " + str(request.headers))
        elif "/chat-message" in request.path and request.method == "POST":
            mes = request.body.decode().split(":", 1)[1]
            mes = mes[::-1]
            mes = mes.replace("}", "", 1)
            mes = mes[::-1]
            mes = html.escape(mes)
            
            if "auth" in request.cookies and logins.find_one({"auth":hashlib.sha256(request.cookies["auth"].encode()).digest()}) != None:
                username = logins.find_one({"auth":hashlib.sha256(request.cookies["auth"].encode()).digest()})["username"]
                print("username is ", username)
                chat.insert_one({"username": username, "message": mes, "id": str(randint(1000000, 9999999))})
            elif "auth" not in request.cookies:
                chat.insert_one({"username": "guest", "message": mes, "id": str(randint(1000000, 9999999))})
            
            response = request.http_version + " 200 OK" + "\r\n"
            response += "Content-Type: text/plain; charset=utf-8" + "\r\n"
                
            txt = "received"
            txt = txt.encode()
            response += "Content-Length: "
            response += str(len(txt)) + "\r\n"
            response += "X-Content-Type-Options: nosniff\r\n\r\n"
            
            response = response.encode('utf-8')
            response += txt
            
            print("headers: " + str(request.headers))
        elif "/chat-history" in request.path and request.method == "GET":
            
            messages = list(chat.find({}))
            for i in messages:
                del i["_id"]
            
            messages = json.dumps(messages).encode()
            
            response = request.http_version + " 200 OK" + "\r\n"
            response += "Content-Type: text/plain; charset=utf-8" + "\r\n"

            response += "Content-Length: "
            response += str(len(messages)) + "\r\n"
            response += "X-Content-Type-Options: nosniff\r\n\r\n"
            
            response = response.encode('utf-8')
            
            response += messages
            
            print("headers: " + str(request.headers))
        elif "/register" in request.path and request.method == "POST":
            
            #username_reg=username&password_reg=password
            body = (request.body).decode().split("&", 1)
            username = body[0].split("=", 1)[1]
            
            password = body[1].split("=", 1)[1]
            salt = bcrypt.gensalt()
            hashed = bcrypt.hashpw(password.encode(), salt)
            
            logins.insert_one({"username": username, "salt":salt, "password": hashed, "auth": ""})
            
            response = request.http_version + " 301 Moved Permanently" + "\r\n"

            response += "Content-Length: "
            response += str(0) + "\r\n"
            response += "Location: /\r\n"
            response += "X-Content-Type-Options: nosniff\r\n\r\n"
            
            response = response.encode('utf-8')
            
            print("logins: ", list(logins.find({})))
        elif "/login" in request.path and request.method == "POST":
            
            response = request.http_version + " 301 Moved Permanently" + "\r\n"
            
            # When a user sends a login request, authenticate the request based on the data stored 
            # in your database. If the [salted hash of the] password matches what you have stored in
            # the database, the user is authenticated.

            # When a user successfully logs in, set an authentication token as a cookie for that user
            # with the HttpOnly directive set. These tokens should be random values that are associated
            # with the user. You must store a hash (no salt) of each token in your database so you can
            # verify them on subsequent requests.

            # The auth token cookie must have an expiration time of 1 hour or longer. 
            # It cannot be a session cookie.

            # Whenever a chat message is sent by an authenticated user, the message should contain their 
            # username instead of "Guest".

            
            #username_login=username&password_login=password
            body = (request.body).decode().split("&", 1)
            username = body[0].split("=", 1)[1]
            password = body[1].split("=", 1)[1]
            verify = "failure"
            
            auth = secrets.token_hex(10)
            
            for i in list(logins.find({})):
                if i["username"] == username and i["password"] == bcrypt.hashpw(password.encode(), i["salt"]):
                    verify = "success"
                    print("matches")
                    hashedAuth = hashlib.sha256(auth.encode()).digest()
                    print("auth: ", auth)
                    print("hashed auth: ", hashedAuth)
                    logins.update_one({"username": username}, {"$set": {"auth": hashedAuth}})
                    
                    request.cookies["auth"] = hashedAuth
                    response += "Set-Cookie: " + "auth=" + auth + "; Max-Age=3600; HttpOnly" + "\r\n"
            
            response += "Content-Length: "
            response += str(0) + "\r\n"
            response += "Location: / \r\n"
            response += "X-Content-Type-Options: nosniff\r\n\r\n"
            
            response = response.encode('utf-8')
            
            print("logins: ", list(logins.find({})))
        elif "DELETE" in request.method:
            mesID = request.path.split("/")[2]
            print("mesID: ", mesID)
            
            checkDelete = None
            checkUser = None
            checkAuth = None
            auth = None
            
            if chat.find_one({"id":mesID}) != None:
                checkDelete = chat.find_one({"id":mesID})
                checkUser = checkDelete["username"]
                print("checkDelete: ", checkDelete)
                print("checkUser: ", checkUser)
                if logins.find_one({"username": checkUser}) != None and "auth" in request.cookies:
                    auth = hashlib.sha256(request.cookies["auth"].encode()).digest()
                    checkAuth = logins.find_one({"username": checkUser})
                    print("checkAuth: ", checkAuth)
            
            if auth != None and checkAuth != None and auth == checkAuth["auth"]:
                chat.delete_one({"id": mesID})
                print("deleted")
                response = request.http_version + " 200 OK" + "\r\n"
            else:
                response = request.http_version + " 403 Forbidden" + "\r\n"
                
            response += "X-Content-Type-Options: nosniff\r\n\r\n"
            response = response.encode('utf-8')
            
        elif ".ico" in request.path:
            response = request.http_version + " 200 OK" + "\r\n"
            response += "Content-Type: image/png" + "\r\n"
            response += "Content-Length: "
            img = open("public/image/flame.png", 'rb')
            img = img.read()
            response += (str(len(img)))
            response += ("\r\nX-Content-Type-Options: nosniff\r\n\r\n")
            response = response.encode('utf-8')
            response += img
        
        self.request.sendall(response)


def main():
    host = "0.0.0.0"
    port = 8080

    socketserver.TCPServer.allow_reuse_address = True

    server = socketserver.TCPServer((host, port), MyTCPHandler)

    print("Listening on port " + str(port))
    sys.stdout.flush()
    sys.stderr.flush()

    server.serve_forever()


if __name__ == "__main__":
    main()
