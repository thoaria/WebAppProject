class Request:

    def __init__(self, request: bytes):
        # TODO: parse the bytes of the request and populate the following instance variables
        self.value = request.decode('utf-8')
        self.value = self.value.split("\r\n")
        self.body = b""
        self.method = ""
        self.path = ""
        self.http_version = ""
        self.headers = {}
        self.cookies = {}
        self.temp = ""
        self.length = 0
        
        # print("here is the value")
        # print(self.value)
        
        self.temp = self.value[0].split()
        # print("self method")
        if len(self.temp) > 0:
            self.method = self.temp[0]
            # print(self.method)
            self.path = self.temp[1]
            self.http_version = self.temp[2]
        
        for i in range(1, len(self.value)-2):
            # self.temp = self.value[i].replace(":", "")
            self.temp = self.value[i].split(":", 1)
            # print("here is self.temp: ")
            # print(self.temp)
            self.headers[self.temp[0].strip()] = self.temp[1].strip()
            # print("here are the headers: ")
            # print(self.headers)
        
        if "Cookie" in self.headers:
            cookieValues = self.headers["Cookie"].split(";", 1)
            for i in cookieValues:
                temp = i.split("=", 1)
                self.cookies[temp[0].strip()] = temp[1]
        
        if "Content-Length" in self.headers:
            # print("there is a content length")
            self.length = int(self.headers["Content-Length"])
            self.body = (self.value[len(self.value)-1]).encode()
        
        # print("length is: ", self.length)
        # print("self headers: ", self.headers)
        print("cookies: ", self.cookies)

        # print("end.")
